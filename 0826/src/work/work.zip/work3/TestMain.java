package work.work3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * @author: 杜少雄 <github.com/shaoxiongdu>
 * @date: 2021年08月25日 | 16:22
 * @description:
 */
public class TestMain {


    public static void main(String[] args) {

        Ui ui = new Ui();

        ui.run();

    }



}
