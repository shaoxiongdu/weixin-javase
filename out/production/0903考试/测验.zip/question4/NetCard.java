package question4;

/**
 * @author: 杜少雄 <github.com/shaoxiongdu>
 * @date: 2021年09月03日 | 16:12
 * @description:
 */
public class NetCard implements PCI{
    @Override
    public void send() {
        System.out.println("网卡底层。。。。 如何传输数据");
    }
}
