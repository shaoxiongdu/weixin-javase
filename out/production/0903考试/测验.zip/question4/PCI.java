package question4;

/**
 * @author: 杜少雄 <github.com/shaoxiongdu>
 * @date: 2021年09月03日 | 16:11
 * @description:
 */
public interface PCI {

    /**
     * 传送数据
     */
    void send();

}
