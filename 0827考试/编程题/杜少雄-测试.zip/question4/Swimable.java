package question4;

/**
 * @author: 杜少雄 <github.com/shaoxiongdu>
 * @date: 2021年08月27日 | 15:40
 * @description: 游泳接口
 */
public interface Swimable {

    /**
     * 游泳方法
     */
    void swim();

}
